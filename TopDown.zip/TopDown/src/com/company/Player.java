package com.company;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import static com.company.Game.*;

//down right up

class Player extends GameObject {
    private final int speed = 3;
    private double spd = speed;
    private final int animationSpeed = 20;
    private Point dir = new Point(1, 0);
    private Rectangle melee = new Rectangle();
    int fireSpeed = 15;
    ArrayList<Animation> anim = new ArrayList<>(8);
    private Animation legAnim, bodyAnim;
    private int health = 100;
    Weapon currentWeapon = null;
    int fireTime;
    int offset = 0;

    Player(double x, double y) {
        super(x, y);
        //legs anim 0 - 4
        add(0, false, 0);
        add(1, 2, false, true);
        add(2, 1, false, true);
        add(3,4, true, true);

        //body anim 5 - 12
        add(0, false, 1);
        add(3, true, 1);
        add(6, false, 1);
        add(1, 2,false, false);
        add(4,5,true,false);
        add(7,8,false,false);

        //sword (body) anim 13 - 20
        add(0,false, 2);
        add(10, false, 2);
        add(15, false, 2);
        add(5, false, 2);
        add(1,2,3,4);
        add(11,12,13,14);
        add(16,17,18,19);
        add(6,7,8,9);

        legAnim = anim.get(0);
        bodyAnim = anim.get(5);
    }

    public void tick() {
        updateRectangle();
        if (getKeysDown() == 2) {
            spd = Math.sqrt(1/2f) * speed;
        } else if (getKeysDown() == 0) {
            legAnim = anim.get(0);
            animate(6,7,8,5, false);
        } else {
            spd = speed;
        }
        yVel = (isDown(KeyEvent.VK_S) ? spd : 0) + (isDown(KeyEvent.VK_W) ? -spd : 0);
        xVel = (isDown(KeyEvent.VK_D) ? spd : 0) + (isDown(KeyEvent.VK_A) ? -spd : 0);
        if (!(xVel == 0 && yVel == 0)) {
            dir = new Point((int)(xVel / spd), (int)(yVel / spd));
            animate(3,4,1,2, true);
            animate(6,7,8,5, false);
        }
        //Collision
        for (Wall obj : currentRoom.walls) {
            if (getOffsetBoundsH().intersects(obj.getBounds())) {
                if (xVel > 0) {
                    x = obj.x - getBounds().width;
                } else {
                    x = obj.x + obj.getBounds().width;
                }
                xVel = 0;
            }
            if (getOffsetBoundsV().intersects(obj.getBounds())) {
                if (yVel > 0) {
                    y = obj.y - getBounds().height - 22;
                } else {
                    y = obj.y + obj.getBounds().height - 22;
                }
                yVel = 0;
            }
        }
        if (currentRoom.getSizeX() > mapX) {
            if (getOffsetBoundsH().x < 0) {
                x = 0;
                xVel = 0;
            }
            if (getOffsetBoundsH().x > currentRoom.getSizeX()) {
                x = currentRoom.getSizeX();
                xVel = 0;
            }
        }

        if (currentRoom.getSizeY() > mapY) {
            if (getOffsetBoundsV().y - 22 < 0) {
                y = 0;
                yVel = 0;
            }
            if (getOffsetBoundsV().y > currentRoom.getSizeY()) {
                y = currentRoom.getSizeY() - 22;
                yVel = 0;
            }
        }

        if (mouseDown && currentWeapon != null) {
            if (currentWeapon.melee()) {
                offset = 24;
                animate(19, 18, 20, 17, false);
            } else {
                animate(10, 11, 12, 9, false);
            }
        } else {
            offset = 0;
        }
        bodyAnim.runAnimation();
        legAnim.runAnimation();
        x += xVel;
        y += yVel;
        //shooting
        if (mouseDown && currentWeapon != null) {
            fireTime++;
            if (fireTime > currentWeapon.fireSpeed()) {
                if (currentWeapon.melee()) {
                    for (int x = 0; x < currentRoom.enemys.size(); x++) {
                        if (melee.intersects(currentRoom.enemys.get(x).getBounds())) {
                            currentRoom.enemys.get(x).lowerHealth(currentWeapon.damage());
                        }
                    }
                    fireTime -= currentWeapon.fireSpeed();
                } else {
                    if (currentWeapon.wavy()) {
                        currentRoom.addBullet(new WavyBullet(x, y, mousePos, currentWeapon.range(), currentWeapon.speed(), false, currentWeapon.damage(), false, currentWeapon.bulletSprite()));
                        currentRoom.addBullet(new WavyBullet(x, y, mousePos, currentWeapon.range(), currentWeapon.speed(), true, currentWeapon.damage(), false, currentWeapon.bulletSprite()));
                    } else {
                        int theta = (currentWeapon.numShots() - 1) / 2 * -currentWeapon.angle();
                        for (int i = 0; i < currentWeapon.numShots(); i++) {
                            currentRoom.addBullet(new Bullet(x, y, mousePos, currentWeapon.range(), currentWeapon.speed(), theta, currentWeapon.damage(), false, currentWeapon.bulletSprite()));
                            theta += currentWeapon.angle();
                        }
                    }
                    fireTime -= currentWeapon.fireSpeed();
                }
            }
        }
        x = (int) x;
        y = (int) y;
    }

    private void updateRectangle() {
        int x = (int)this.x;
        int y = (int)this.y;
        if (dir.x == 1) {
            melee = new Rectangle(x + 48, y - 48, 96, 144);
        }
        if (dir.x == -1) {
            melee = new Rectangle(x - 96, y - 48, 96, 144);
        }
        if (dir.y == -1) {
            melee = new Rectangle(x - 48, y - 96, 144, 96);
        }
        if (dir.y == 1) {
            melee = new Rectangle(x - 48, y + 48, 144, 96);
        }
    }

    public void render(Graphics g) {
        legAnim.drawAnimation(g, x, y, 0);
        bodyAnim.drawAnimation(g, x, y, offset);
    }

    void lowerHealth(int damage) {
        health -= damage;
    }

    int getHealth() {
        return health;
    }

    private void animate(int left, int right, int down, int up, boolean legs) {
        if (legs) {
            if (dir.equals(new Point(0, -1))) {
                legAnim = anim.get(down);
            }
            if (dir.equals(new Point(0, 1))) {
                legAnim = anim.get(up);
            }
            if (dir.equals(new Point(-1, 0))) {
                legAnim = anim.get(left);
            }
            if (dir.equals(new Point(1, 0))) {
                legAnim = anim.get(right);
            }
            if (dir.equals(new Point(-1, -1))) {
                legAnim = anim.get(down);
            }
            if (dir.equals(new Point(1, 1))) {
                legAnim = anim.get(up);
            }
            if (dir.equals(new Point(-1, 1))) {
                legAnim = anim.get(up);
            }
            if (dir.equals(new Point(1, -1))) {
                legAnim = anim.get(down);
            }
        } else {
            if (dir.equals(new Point(0, -1))) {
                bodyAnim = anim.get(down);
            }
            if (dir.equals(new Point(0, 1))) {
                bodyAnim = anim.get(up);
            }
            if (dir.equals(new Point(-1, 0))) {
                bodyAnim = anim.get(left);
            }
            if (dir.equals(new Point(1, 0))) {
                bodyAnim = anim.get(right);
            }
            if (dir.equals(new Point(-1, -1))) {
                bodyAnim = anim.get(down);
            }
            if (dir.equals(new Point(1, 1))) {
                bodyAnim = anim.get(up);
            }
            if (dir.equals(new Point(-1, 1))) {
                bodyAnim = anim.get(up);
            }
            if (dir.equals(new Point(1, -1))) {
                bodyAnim = anim.get(down);
            }
        }
    }

    private void add(int spr, boolean flip, int spriteNum) {
        BufferedImage[] sprites;
        if (spriteNum == 0) {
             sprites = legSprites;
        } else if (spriteNum == 1) {
            sprites = bodySprites;
        } else {
            sprites = swordSprites;
        }
        if (flip) {
            anim.add(new Animation(animationSpeed, new BufferedImage[]{flipped(sprites[spr])}));
            anim.add(new Animation(animationSpeed, new BufferedImage[]{sprites[spr]}));
        } else {
            anim.add(new Animation(animationSpeed, new BufferedImage[]{sprites[spr]}));
        }
    }

    private void add(int spr1, int spr2, boolean flip, boolean legs) {
        BufferedImage[] sprites = legs ? legSprites : bodySprites;
        if (flip) {
            anim.add(new Animation(animationSpeed, new BufferedImage[]{flipped(sprites[spr1]), flipped(sprites[spr2])}));
            anim.add(new Animation(animationSpeed, new BufferedImage[]{sprites[spr1], sprites[spr2]}));
        } else {
            anim.add(new Animation(animationSpeed, new BufferedImage[]{sprites[spr1], sprites[spr2]}));
        }
    }

    private void add(int spr1, int spr2, int spr3, int spr4) {
        anim.add(new Animation(animationSpeed / 2, new BufferedImage[]{swordSprites[spr1], swordSprites[spr2], swordSprites[spr3], swordSprites[spr4]}));
    }

    void setPos(Point pos) {
        x = pos.x;
        y = pos.y;
    }

    public double getX() {
        return x + 12 + getBounds().width / 2f;
    }

    public double getY() {
        return y + 33 + getBounds().height / 2f;
    }
    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y + 22,30,44);
    }

    private Rectangle getOffsetBoundsH() {
        return new Rectangle((int)(x + xVel), (int)y + 22,getBounds().width, getBounds().height);
    }

    private Rectangle getOffsetBoundsV() {
        return new Rectangle((int)x, (int)(y + 22 + yVel),getBounds().width, getBounds().height);
    }
}