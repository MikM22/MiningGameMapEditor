package com.company;

import org.w3c.dom.css.Rect;

import java.awt.*;

import static com.company.Game.*;

class Camera {
    private double x,y;

    double getX() {
        return x;
    }

    double getY() {
        return y;
    }

    void setPos(Point pos) {
        x = pos.x;
        y = pos.y;
    }

    Camera() {
        x = 0;
        y = 0;
        System.out.println(x + ", " + y);
    }

    void tick() {
        if (currentRoom.getSizeX() > mapX && currentRoom.getSizeY() > mapY) {
            x += ((player.getBounds().x - x) - (mapX / 2f)) * 0.05f;
            y += ((player.getBounds().y - y) - (mapY / 2f)) * 0.05f;
        }
        //x = toFollow.getX() - mapX/2f;
        //y = toFollow.getY() - mapY/2f;
        if (currentRoom.getSizeX() > mapX) {
            if (x < 0) {
                x = 0;
            }
            if (x > currentRoom.getSizeX() - mapX + player.getBounds().width + 15) {
                x = mapX + player.getBounds().width + 15;
            }
        }
        if (currentRoom.getSizeY() > mapY) {
            if (y < 0) {
                y = 0;
            }
            if (y > currentRoom.getSizeY() - mapY + player.getBounds().height + 39) {
                y = mapY + player.getBounds().height + 39;
            }
        }
    }
}
