package com.company;

import java.awt.*;

import static com.company.Game.*;

class UI {
    private final int xOffset = 20, yOffset = 40;

    void render(Graphics og) {
        Rectangle hpbar = edgeConstraint(10, 10, 0, 1, player.getHealth(), 50);
        Graphics2D g = (Graphics2D) og;
        g.setColor(Color.black);
        g.draw(hpbar);
        g.setColor(Color.GREEN);
        g.fill(hpbar);
    }
    private Rectangle edgeConstraint(int distFromEdge1, int distFromEdge2, int edgeX, int edgeY, int w, int h) {
        int x, y;
        if (edgeX == 0) {
            x = distFromEdge1 + (int)camera.getX();
        } else {
            x = mapX - w - distFromEdge1 - xOffset + (int)camera.getX();
        }
        if (edgeY == 0) {
            y = distFromEdge2  + (int)camera.getY();
        } else {
            y = mapY - h - distFromEdge2 - yOffset + (int)camera.getY();
        }
        return new Rectangle(x,y,w,h);
    }
}
