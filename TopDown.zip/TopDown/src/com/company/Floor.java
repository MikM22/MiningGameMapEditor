package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Floor extends GameObject {
    private BufferedImage img;
    Floor(double x, double y, BufferedImage img) {
        super(x, y);
        this.img = img;
    }

    public void tick() {

    }

    public void render(Graphics g) {
        g.drawImage(img, (int)x, (int)y, null);
    }

    public Rectangle getBounds() {
        return null;
    }
}
