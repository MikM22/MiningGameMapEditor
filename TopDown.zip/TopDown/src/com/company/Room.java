package com.company;

import java.awt.*;
import java.util.ArrayList;

class Room {
    ArrayList<GameObject> art = new ArrayList<>();
    ArrayList<Door> doors = new ArrayList<>();
    ArrayList<GameObject> objects = new ArrayList<>();
    ArrayList<Wall> walls = new ArrayList<>();
    ArrayList<Weapon> droppedWeapons = new ArrayList<>();
    ArrayList<GameObject> bullets = new ArrayList<>();
    ArrayList<GameObject> enemyBullets = new ArrayList<>();
    ArrayList<Enemy> enemys = new ArrayList<>();

    private int sizeX, sizeY;

    Room(int sizeX, int sizeY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;
    }
    void tick() {
        for (int i = 0; i < objects.size(); i++) {
            objects.get(i).tick();
        }
    }
    void render(Graphics g) {
        for (int i = 0; i < art.size(); i++) {
            art.get(i).render(g);
        }
        for (GameObject obj : objects) {
            obj.render(g);
        }
    }
    void addFloor(Floor obj) {
        art.add(obj);
    }
    void addDoor(Door obj) {
        doors.add(obj);
    }
    void addWall(Wall obj) {
        art.add(obj);
        walls.add(obj);
    }
    void addWeapon(Weapon obj) {
        art.add(obj);
        droppedWeapons.add(obj);
    }
    void addPlayer(Player obj) {
        objects.add(obj);
    }
    void addBullet(GameObject obj) {
        objects.add(obj);
        bullets.add(obj);
    }
    void addEnemy(Enemy obj) {
        objects.add(obj);
        enemys.add(obj);
    }
    void addEnemyBullet(GameObject obj) {
        objects.add(obj);
        enemyBullets.add(obj);
    }
    int getSizeX() {
        return sizeX;
    }
    int getSizeY() {
        return sizeY;
    }
}
