package com.company;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

class Animation {

    private int speed;
    private int frame;
    private int time;
    private BufferedImage[] img;
    private BufferedImage currentImg;

    Animation(int speed, BufferedImage[] img){
        this.speed = speed;
        this.img = img;
        currentImg = img[0];
    }

    void runAnimation(){
        //this goes once a tick
        time++;
        if (time > speed) {
            frame++;
            time -= speed;
        }
        if (frame == img.length) {
            frame = 0;
        }
        currentImg = img[frame];
    }

    void drawAnimation(Graphics g, double x, double y, int offset){
        g.drawImage(currentImg, (int)x - offset, (int)y, null);
    }

    void setSpeed(int speed) {
        this.speed = speed;
    }
}
