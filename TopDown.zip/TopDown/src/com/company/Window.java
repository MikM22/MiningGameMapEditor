package com.company;

import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

class Window {
    JFrame frame;
    Window(int w, int h, Game game) {
        frame = new JFrame("Top Down");
        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                Game.mapX = e.getComponent().getSize().width;
                Game.mapY = e.getComponent().getSize().height;
            }
        });
        game.setFocusable(true);
        frame.add(game);
        frame.setPreferredSize(new Dimension(w,h));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
