package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

import static com.company.Game.*;

class Enemy extends GameObject {
    private Animation walk, redWalk, current;
    private int health = 80;
    private int damageFrames;
    private int attackFrame;
    private boolean tickDamageFrames;

    Enemy (int sentX, int sentY, BufferedImage[] img) {
        super(sentX, sentY);
        int animationSpeed = 15;
        walk = new Animation(animationSpeed, img);
        redWalk = new Animation(animationSpeed, red(img));
        current = walk;
        x = sentX;
        y = sentY;
    }

    public void tick() {
        if (tickDamageFrames) {
            damageFrames++;
            if (damageFrames > 5) {
                current = walk;
                damageFrames = 0;
                tickDamageFrames = false;
            }
        }
        double difx = player.x - x;
        double dify = player.y - y;
        double dir = Math.atan2(dify, difx);
        int speed = 1;
        xVel = Math.cos(dir) * speed;
        yVel = Math.sin(dir) * speed;
        //Shooting
        attackFrame++;
        int attackSpeed = 10;
        if (attackFrame > attackSpeed) {
            attackFrame = 0;
            currentRoom.addEnemyBullet(new Bullet(x, y, new Point((int)player.getX(), (int)player.getY()), 6, 6, 0, 3, true, bullet));
        }
        //Collision
        for (Wall obj : currentRoom.walls) {
            if (getOffsetBoundsH().intersects(obj.getBounds())) {
                if (xVel > 0) {
                    x = obj.x - getBounds().width;
                } else {
                    x = obj.x + obj.getBounds().width;
                }
                xVel = 0;
            }
            if (getOffsetBoundsV().intersects(obj.getBounds())) {
                if (yVel > 0) {
                    y = obj.y - getBounds().height;
                } else {
                    y = obj.y + obj.getBounds().height;
                }
                yVel = 0;
            }
        }
        current.runAnimation();
        x += xVel;
        y += yVel;
    }

    void lowerHealth(int damage) {
        health -= damage;
        if (health <= 0) {
            currentRoom.objects.remove(this);
            currentRoom.enemys.remove(this);
        }
        tickDamageFrames = true;
        damageFrames = 0;
        current = redWalk;
        System.out.println(health);
    }

    public void render(Graphics g) {
        current.drawAnimation(g, x, y, 0);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x,(int)y,30,25);
    }

    private Rectangle getOffsetBoundsH() {
        return new Rectangle((int)(x + xVel), (int)y, getBounds().width, getBounds().height);
    }

    private Rectangle getOffsetBoundsV() {
        return new Rectangle((int)x, (int)(y + yVel), getBounds().width, getBounds().height);
    }

    private BufferedImage[] red(BufferedImage[] imgs) {
        BufferedImage[] red = new BufferedImage[imgs.length];
        for (int i = 0; i < imgs.length; i++) {
            red[i] = new BufferedImage(imgs[i].getWidth(), imgs[i].getHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = red[i].createGraphics();
            g.drawImage(imgs[i], 0, 0, null);
            g.setColor(new Color(255, 0, 0, 125));
            for (int x = 0; x < red[i].getWidth(); x++) {
                for (int y = 0; y < red[i].getHeight(); y++) {
                    if (colorAt(x, y, red[i])) {
                        g.fillRect(x, y, 1, 1);
                    }
                }
            }
            g.dispose();
        }
        return red;
    }

    private boolean colorAt(int x, int y, BufferedImage img) {
        if (x >= img.getWidth() || y >= img.getHeight()) {
            return false;
        }
        return ((img.getRGB(x, y) >> 24) & 255) == 255;
    }
}