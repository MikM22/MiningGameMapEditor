package com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class Game extends Canvas implements Runnable {
    private static final long serialVersionUID = 1L;
    static int mapX = 1000, mapY = 800;
    static BufferedImage[] legSprites = new BufferedImage[5], bodySprites = new BufferedImage[9], swordSprites = new BufferedImage[20];
    static BufferedImage bullet, glow;
    private BufferedImage legSheet, bodySheet, swordSheet, grass, wand, branch, swordBullet, tile;
    private BufferedImage[] tiles = new BufferedImage[64];
    private int fps;
    private boolean running = false;
    private Thread thread;
    private static Room room1 = new Room(2000, 1600);
    private static Room room2 = new Room(500,500);
    private Room[] doorRooms = new Room[]{room2, room1};
    private int r = 0;
    static Room currentRoom = room1;
    private static ArrayList<Integer> keysDown = new ArrayList<>(0);
    static boolean mouseDown;
    static Point mousePos;
    private Window window;
    static Camera camera;
    static Player player;
    private UI ui = new UI();

    public static void main(String[] args) {
        new Game();
    }
    private Game() {
        window = new Window(mapX, mapY, this);
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (!keysDown.contains(e.getKeyCode()) && (e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_A || e.getKeyCode() == KeyEvent.VK_S || e.getKeyCode() == KeyEvent.VK_D)) {
                    keysDown.add(e.getKeyCode());
                }
                if (e.getKeyCode() == KeyEvent.VK_E) {
                    int temp = currentRoom.droppedWeapons.size();
                    for (int i = 0; i < temp; i++) {
                        if (player.getBounds().intersects(currentRoom.droppedWeapons.get(i).getBounds())) {
                            if (player.currentWeapon != null) {
                                player.currentWeapon.setPos(currentRoom.droppedWeapons.get(i).x, currentRoom.droppedWeapons.get(i).y);
                                currentRoom.addWeapon(player.currentWeapon);
                            }
                            player.currentWeapon = currentRoom.droppedWeapons.get(i);
                            for (int x = 0; x < 4; x++) {
                                player.anim.get(x + 9).setSpeed(player.currentWeapon.fireSpeed() / 2);
                            }
                            player.offset = 0;
                            currentRoom.art.remove(currentRoom.droppedWeapons.get(i));
                            currentRoom.droppedWeapons.remove(currentRoom.droppedWeapons.get(i));
                            break;
                        }
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_R) {
                    if (currentRoom == room1) {
                        currentRoom = room2;
                        player.setPos(new Point(100,100));
                    } else {
                        currentRoom = room1;
                        player.setPos(new Point(100,100));
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_F) {
                    System.out.println(fps);
                }
            }
            public void keyReleased(KeyEvent e) {
                keysDown.remove(Integer.valueOf(e.getKeyCode()));
            }
        });
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseDown = true;
                player.fireTime = player.fireSpeed;
            }
            public void mouseReleased(MouseEvent e) {
                mouseDown = false;
            }
        });

        //images
        BufferedImage[] slime = new BufferedImage[2];
        try {
            swordBullet = getImage("meleeprojectile", 18, 9, true);
            tile = getImage("tiles", false);
            legSheet = getImage("legs", false);
            bodySheet = getImage("body", false);
            bullet = getImage("waterdrop", 18, 9, true);
            glow = getImage("glow", 48, 48, false);
            branch = getImage("t0sword", 48, 48, true);
            wand = getImage("t0water", 48, 48, true);
            slime = new BufferedImage[]{outline(resizeImage(ImageIO.read(Game.class.getResource("images/slime.png")).getSubimage(0, 0, 6, 5), 36, 25)), outline(resizeImage(ImageIO.read(Game.class.getResource("images/slime.png")).getSubimage(6, 0, 6, 5), 36, 25))};
            grass = getImage("grass", 48, 48, false);
            swordSheet = getImage("sword", false);
        } catch (IOException e) {
            System.err.println("couldn't get images");
        }
        //playerSheet cutting
        int z = 0;
        for (int y = 0; y<3; y++) {
            for (int x = 0; x<3; x++) {
                bodySprites[z] = outline(resizeImage(bodySheet.getSubimage(x * 5, y * 11, 5, 11), 30, 66));
                z++;
            }
        }
        z = 0;
        for (int y = 0; y<8; y++) {
            for (int x = 0; x<8; x++) {
                tiles[z] = resizeImage(tile.getSubimage(x * 16, y * 16, 16, 16), 48, 48);
                z++;
            }
        }
        for (int x = 0; x<5; x++) {
            legSprites[x] = outline(resizeImage(legSheet.getSubimage(x * 5, 0, 5, 11), 30, 66));
        }
        z = 0;
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 5; x++) {
                swordSprites[z] = outline(resizeImage(swordSheet.getSubimage(x * 13, y * 11, 13, 11), 78, 66));
                z++;
            }
        }
        player = new Player(100, 100);
        loadRoom(room1, 43, "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,12f10f10f10f0,x12f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f1f3,13w3w3w3w3,x13w0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f1f1f1f3w5w4f6w3w0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f1f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f0f0f0f0f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f1f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f1f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f0f0f0f0f0f0f0f0f1f1f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f2f0f0f0f0f0f0f0f0f0f0f1f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f2f2f2f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f1f1f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f");

        room1.addWeapon(new Weapon(400, 100, swordBullet, branch, 4, 1f, 7, false, 6, 8, 4, true));
        room1.addWeapon(new Weapon(100, 400, bullet, wand, 10, 4, 5, 2, true, false));
        room1.addEnemy(new Enemy(500, 500, slime));
        room1.addPlayer(player);

        //room2
        room2.addPlayer(player);
        loadRoom(room2, 21, "14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f15w16w16w16w16w16w16w16w16w16w16w16wr15w14f14f14f14f14f14f14f14frrr16w3w3w3w3w3w3w3w3w3w3w3wr16w14f14f14f14f14f14f14f14frrr16w18,20w18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18,19w18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr16w18f18f18f18f18f18f18f18f18f18f18fr16w14f14f14f14f14f14f14f14frrr15wrr16wrr16wrr16wrr16wrr16w4frr16wrr16wrr16wrr16wrr16wrr15w14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f14f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f");
                camera = new Camera();
        start();
    }
    private boolean isNumber(char c) {
        return !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
    }

    static boolean isDown(int keyCode) {
        if (keysDown == null) {
            return false;
        }
        return keysDown.contains(keyCode);
    }
    static int getKeysDown() {
        return keysDown.size();
    }

    private void start() {
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    private void stop() {
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void tick() {
        //updates 60 times a second
        currentRoom.tick();
        for (Door obj : currentRoom.doors) {
            if (player.getBounds().intersects(obj.getBounds())) {
                if (obj.getDestination().getSizeX() <= mapX) {
                    camera.setPos(new Point(0,0));
                }
                currentRoom = obj.getDestination();
            }
        }
    }

    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        //DRAW THINGS HERE//
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0, 0, mapX, mapY);
        g.translate((int)-camera.getX(), (int)-camera.getY());
        currentRoom.render(g);
        ui.render(g);
        mousePos = new Point(MouseInfo.getPointerInfo().getLocation().x - window.frame.getLocationOnScreen().x + (int)camera.getX(), MouseInfo.getPointerInfo().getLocation().y - window.frame.getLocationOnScreen().y + (int)camera.getY());
        camera.tick();
        g.translate((int)camera.getX(), (int)camera.getY());
        ////////////////////
        g.dispose();
        bs.show();
    }

    public void run() {
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) /ns;
            lastTime = now;
            while(delta >= 1) {
                tick();
                render();
                frames++;
                delta--;
            }
            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                fps = frames;
                frames = 0;
            }
        }
        stop();
    }

    private void loadRoom(Room room1, int xSize, String s) {
        StringBuilder tile = new StringBuilder();
        boolean flip = false;
        int numRotations = 0;
        int xPos = 0, yPos = 0;

        for (int x = 0; x < s.length() ; x++) {
            if (isNumber(s.charAt(x))) {
                if (s.charAt(x) == ',') {
                    if (flip) {
                        room1.addFloor(new Floor(xPos, yPos, flipped(tiles[Integer.parseInt(tile.toString())])));
                    } else {
                        room1.addFloor(new Floor(xPos, yPos, tiles[Integer.parseInt(tile.toString())]));
                    }
                    flip = false;
                    tile.setLength(0);
                } else {
                    tile.append(s.charAt(x));
                    if (tile.charAt(0) == '4') {
                        room1.addDoor(new Door(xPos, yPos, doorRooms[r]));
                        System.out.println(doorRooms[r]);
                        r++;
                    }
                }
            } else {
                if (s.charAt(x) == 'x') {
                    flip = true;
                } else if (s.charAt(x) == 'r') {
                    numRotations++;
                } else if (s.charAt(x) == 'f') {
                    if (flip) {
                        room1.addFloor(new Floor(xPos, yPos, rotateImage(flipped(tiles[Integer.parseInt(tile.toString())]), numRotations * 90)));
                    } else {
                        room1.addFloor(new Floor(xPos, yPos, rotateImage(tiles[Integer.parseInt(tile.toString())], numRotations * 90)));
                    }
                } else if (s.charAt(x) == 'w') {
                    if (flip) {
                        room1.addWall(new Wall(xPos, yPos, rotateImage(flipped(tiles[Integer.parseInt(tile.toString())]), numRotations * 90)));
                    } else {
                        room1.addWall(new Wall(xPos, yPos, rotateImage(tiles[Integer.parseInt(tile.toString())], numRotations * 90)));
                    }
                }
                if (s.charAt(x) != 'x' && s.charAt(x) != 'r') {
                    flip = false;
                    numRotations = 0;
                    xPos += 48;
                    if (xPos >= 48 * xSize) {
                        xPos = 0;
                        yPos += 48;
                    }
                }
                tile.setLength(0);
            }
        }
    }

    private BufferedImage resizeImage(final BufferedImage image, int width, int height) {
        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }

    static BufferedImage flipped(BufferedImage image) {
        AffineTransform tx = AffineTransform.getScaleInstance(-1, 1);
        tx.translate(-image.getWidth(null), 0);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
        return op.filter(image, null);
    }

    private BufferedImage outline(BufferedImage img) {
        BufferedImage outlined = new BufferedImage(img.getWidth() + 2, img.getHeight() + 2, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g3 = outlined.createGraphics();
        g3.drawImage(img, 1, 1, null);
        calculations = new BufferedImage(img.getWidth() + 2, img.getHeight() + 2, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = calculations.createGraphics();
        g2.drawImage(img, 1, 1, null);
        g2.dispose();
        Graphics2D g = outlined.createGraphics();
        g.setColor(Color.black);
        for (int x = 0; x < outlined.getWidth(); x++) {
            for (int y = 0; y < outlined.getHeight(); y++) {
                if (colorAt(x,y)) {
                    if (!colorAt(x, y + 1)) {
                        g.fillRect(x, y + 1, 1, 1);
                    }
                    if (!colorAt(x + 1, y)) {
                        g.fillRect(x + 1, y, 1, 1);
                    }
                    if (!colorAt(x, y - 1)) {
                        g.fillRect(x, y - 1, 1, 1);
                    }
                    if (!colorAt(x - 1, y)) {
                        g.fillRect(x - 1, y, 1, 1);
                    }
                    if (!colorAt(x + 1, y + 1)) {
                        g.fillRect(x + 1, y + 1, 1, 1);
                    }
                    if (!colorAt(x + 1, y - 1)) {
                        g.fillRect(x + 1, y - 1, 1, 1);
                    }
                    if (!colorAt(x - 1, y + 1)) {
                        g.fillRect(x - 1, y + 1, 1, 1);
                    }
                    if (!colorAt(x - 1, y - 1)) {
                        g.fillRect(x - 1, y - 1, 1, 1);
                    }
                }
            }
        }
        g.dispose();
        return outlined;
    }

    private BufferedImage calculations;
    private boolean colorAt(int x, int y) {
        if (x >= calculations.getWidth() || y >= calculations.getHeight()) {
            return false;
        }
        return ((calculations.getRGB(x, y) >> 24) & 255) == 255;
    }

    private BufferedImage getImage(String filename, int x, int y, boolean outlined) throws IOException {
        if (outlined) {
            return outline(resizeImage(ImageIO.read(Game.class.getResource("images/" + filename + ".png")), x, y));
        } else {
            return resizeImage(ImageIO.read(Game.class.getResource("images/" + filename + ".png")), x, y);
        }
    }

    private BufferedImage getImage(String filename, boolean outlined) throws IOException {
        if (outlined) {
            return outline(ImageIO.read(Game.class.getResource("images/" + filename + ".png")));
        } else {
            return ImageIO.read(Game.class.getResource("images/" + filename + ".png"));
        }
    }

    private BufferedImage rotateImage(BufferedImage image, int angle) {
        final double rads = Math.toRadians(angle);
        final double sin = Math.abs(Math.sin(rads));
        final double cos = Math.abs(Math.cos(rads));
        final int w = (int) Math.floor(image.getWidth() * cos + image.getHeight() * sin);
        final int h = (int) Math.floor(image.getHeight() * cos + image.getWidth() * sin);
        final BufferedImage rotatedImage = new BufferedImage(w, h, image.getType());
        final AffineTransform at = new AffineTransform();
        at.translate(w / 2f, h / 2f);
        at.rotate(rads,0, 0);
        at.translate(-image.getWidth() / 2f, -image.getHeight() / 2f);
        final AffineTransformOp rotateOp = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        return rotateOp.filter(image,rotatedImage);
    }
}
