package com.company;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.image.BufferedImage;

import static com.company.Game.*;


class WavyBullet extends GameObject {
    private final int multiplier;
    private double range;
    private int speed, damage;
    private boolean enemyBullet;
    private BufferedImage img;
    private double dir, ix, iy, time;

    WavyBullet(double sentX, double sentY, Point target, double range, int speed, boolean flipped, int damage, boolean enemyBullet, BufferedImage img) {
        super(sentX + 17, sentY + 17);
        multiplier = flipped ? 1 : -1;
        this.speed = speed;
        this.range = range;
        this.enemyBullet = enemyBullet;
        this.damage = damage;
        this.img = img;
        x = sentX + 25;
        y = sentY + 25;
        ix = x;
        iy = y;
        target = new Point(target.x - 12, target.y - 33);
        double dx = target.x - x;
        double dy = target.y - y;
        dir = Math.atan2(dy, dx);
    }

    public void tick() {
        //distance = rate * time
        double d = speed * time;
        if (d > range * 10) {
            currentRoom.objects.remove(this);
            currentRoom.bullets.remove(this);
        }
        xVel = Math.cos(dir) * speed;
        yVel = Math.sin(dir) * speed;
        x += xVel;
        y += yVel;
        double beta = dir + Math.PI / 2;
        final double frequency = 3;
        final double amplitude = 3;
        double distance = multiplier * amplitude * Math.sin(time * frequency);
        ix = x + Math.cos(beta) * distance;
        iy = y + Math.sin(beta) * distance;
        x = ix;
        y = iy;
        time += .1;
        Bullet.checkCollision(this, getRotatedBounds(), enemyBullet, damage);
    }

    public void render(Graphics g) {
        Bullet.drawBullet(g, dir, x, y, img);
    }

    private Area getRotatedBounds() {
        Area a = new Area(getBounds());
        AffineTransform af = new AffineTransform();
        af.rotate(dir, x, y);
        return a.createTransformedArea(af);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, img.getWidth(), img.getHeight());
    }
}
