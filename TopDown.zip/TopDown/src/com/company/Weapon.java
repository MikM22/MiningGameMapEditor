package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

import static com.company.Game.glow;

class Weapon extends GameObject {
    private BufferedImage bulletSprite;
    private int fireSpeed;
    private double range;
    private int speed;
    private boolean wavy;
    private int numShots;
    private int angle;
    private int damage;
    private Boolean melee;
    private BufferedImage weaponSprite;

    Weapon(double x, double y, BufferedImage bulletSprite, BufferedImage weaponSprite, int fireSpeed, double range, int speed, boolean wavy, int numShots, int angle, int damage, boolean melee) {
        super(x, y);
        this.bulletSprite = bulletSprite;
        this.fireSpeed = fireSpeed;
        this.range = range;
        this.speed = speed;
        this.wavy = wavy;
        this.numShots = numShots;
        this.angle = angle;
        this.damage = damage;
        this.weaponSprite = weaponSprite;
        this.melee = melee;
    }

    Weapon(double x, double y, BufferedImage bulletSprite, BufferedImage weaponSprite, int fireSpeed, double range, int speed, int damage, boolean wavy, boolean melee) {
        super(x, y);
        this.bulletSprite = bulletSprite;
        this.fireSpeed = fireSpeed;
        this.range = range;
        this.speed = speed;
        this.wavy = wavy;
        this.damage = damage;
        this.weaponSprite = weaponSprite;
        this.melee = melee;
    }

    BufferedImage bulletSprite() {
        return bulletSprite;
    }

    int fireSpeed() {
        return fireSpeed;
    }

    double range() {
        return range;
    }

    int speed() {
        return speed;
    }

    boolean wavy() {
        return wavy;
    }

    int numShots() {
        return numShots;
    }

    int angle() {
        return angle;
    }

    int damage() {
        return damage;
    }

    BufferedImage weaponSprite() {
        return weaponSprite;
    }

    boolean melee() {
        return melee;
    }

    void setPos(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void tick() {

    }

    public void render(Graphics g) {
        g.drawImage(glow, (int)x, (int)y, null);
        g.drawImage(weaponSprite, (int)x, (int)y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, weaponSprite.getWidth(), weaponSprite.getHeight());
    }

    public String toString() {
        return speed + "";
    }
}
