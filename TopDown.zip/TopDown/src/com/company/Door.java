package com.company;

import java.awt.*;

class Door extends GameObject {
    private Room destination;
    Door (int x, int y, Room destination) {
        super(x, y);
        this.destination = destination;
    }

    public void tick() {

    }

    public void render(Graphics g) {

    }

    public Rectangle getBounds() {
        return new Rectangle((int)x,(int)y,48,48);
    }

    Room getDestination() {
        return destination;
    }
}
