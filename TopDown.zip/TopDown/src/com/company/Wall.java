package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

class Wall extends GameObject {
    private BufferedImage img;
    Wall (int x, int y, BufferedImage img) {
        super(x, y);
        this.img = img;
    }

    public void tick() {

    }

    public void render(Graphics g) {
        g.drawImage(img, (int)x, (int)y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x,(int)y,img.getWidth(),img.getHeight());
    }
}
