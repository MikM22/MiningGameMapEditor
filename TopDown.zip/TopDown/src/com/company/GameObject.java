package com.company;

import java.awt.*;

public abstract class GameObject {
    double x,y;
    double xVel = 0, yVel = 0;

    GameObject(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public abstract void tick();
    public abstract void render(Graphics g);
    public abstract Rectangle getBounds();

    double getX() {
        return x;
    }

    double getY() {
        return y;
    }
}
