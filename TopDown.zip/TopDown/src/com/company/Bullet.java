package com.company;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.image.BufferedImage;

import static com.company.Game.*;


class Bullet extends GameObject {
    private int speed, damage;
    private boolean enemyBullet;
    private BufferedImage img;
    private double time, dir, range;

    Bullet(double sentX, double sentY, Point target, double range, int speed, int spreadAngle, int damage, boolean enemyBullet, BufferedImage img) {
        super(sentX + 17, sentY + 17);
        this.speed = speed;
        this.damage = damage;
        this.enemyBullet = enemyBullet;
        this.range = range;
        this.img = img;
        x = sentX + 25;
        y = sentY + 25;
        target = new Point(target.x - 12, target.y - 33);
        double dx = target.x - x;
        double dy = target.y - y;
        dir = Math.atan2(dy, dx);
        dir += Math.toRadians(spreadAngle);
        xVel = Math.cos(dir) * speed;
        yVel = Math.sin(dir) * speed;
    }

    public void tick() {
        double d = speed * time;
        if (d > range * 10) {
            currentRoom.objects.remove(this);
            currentRoom.bullets.remove(this);
        }
        x += xVel;
        y += yVel;
        time += .1;
        checkCollision(this, getRotatedBounds(), enemyBullet, damage);
    }

    public void render(Graphics g) {
        drawBullet(g, dir, x, y, img);
    }

    static void drawBullet(Graphics g, double dir, double x, double y, BufferedImage img) {
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(Color.black);
        AffineTransform old = g2.getTransform();
        g2.rotate(dir, x, y);
        g2.drawImage(img, (int)x, (int)y, null);
        g2.setTransform(old);
    }

    static void checkCollision(GameObject bullet, Area bounds, boolean enemyBullet, int damage) {
        for (Wall obj : currentRoom.walls) {
            if (bounds.intersects(obj.getBounds())) {
                currentRoom.objects.remove(bullet);
                currentRoom.bullets.remove(bullet);
            }
        }
        if (enemyBullet) {
            if (bounds.intersects(player.getBounds())) {
                player.lowerHealth(damage);
                currentRoom.objects.remove(bullet);
                currentRoom.bullets.remove(bullet);
            }
        } else {
            for (int x = 0; x < currentRoom.enemys.size(); x++) {
                if (bounds.intersects(currentRoom.enemys.get(x).getBounds())) {
                    currentRoom.enemys.get(x).lowerHealth(damage);
                    currentRoom.objects.remove(bullet);
                    currentRoom.bullets.remove(bullet);
                }
            }
        }
    }

    private Area getRotatedBounds() {
        Area a = new Area(getBounds());
        AffineTransform af = new AffineTransform();
        af.rotate(dir, x, y);
        return a.createTransformedArea(af);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, img.getWidth(), img.getHeight());
    }
}
