package com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class Main extends Canvas implements Runnable {
    private BufferedImage[] tiles = new BufferedImage[64];
    private final int mapX = 43, mapY = 35;
    private String[][] map = new String[mapX][mapY];
    private final int tw = 48, actualTiles = 13;
    private BufferedImage tile;
    private int selectedTile;
    private boolean running;
    private Point mp = new Point(0,0);
    private Thread thread;
    private String[][] output = new String[mapX][mapY];
    private int camX, camY;
    private boolean shiftHeld;

    public static void main(String[] args) {
        new Main();
    }
    private Main() {
        for (int y = 0; y < mapY; y++) {
            for (int x = 0; x < mapX; x++) {
                output[x][y] = "0f";
                map[x][y] = "0";
            }
        }
        new Window(1000, 800, this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (shiftHeld) {
                        map[mp.x / tw][mp.y / tw] = map[mp.x / tw][mp.y / tw] + "," + selectedTile + "";
                        output[mp.x / tw][mp.y / tw] = map[mp.x / tw][mp.y / tw] + "f";
                    } else {
                        map[mp.x / tw][mp.y / tw] = selectedTile + "";
                        output[mp.x / tw][mp.y / tw] = map[mp.x / tw][mp.y / tw] + "f";
                    }
                } else if (e.getButton() == MouseEvent.BUTTON3) {
                    map[mp.x / tw][mp.y / tw] = "";
                    output[mp.x / tw][mp.y / tw] = map[mp.x / tw][mp.y / tw] + "f";
                } else if (e.getButton() == MouseEvent.BUTTON2) {
                    output[mp.x / tw][mp.y / tw] = "INSERT," + output[mp.x / tw][mp.y / tw];
                }
            }
        });
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_R) {
                    for (int y = 0; y < mapY; y++) {
                        for (int x = 0; x < mapX; x++) {
                            map[x][y] = "0";
                        }
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_E) {
                    System.out.println(output[mp.x / tw][mp.y / tw]);
                }
                if (e.getKeyCode() == KeyEvent.VK_F) {
                    if (output[mp.x / tw][mp.y / tw].substring(0, 1).equals("x")) {
                        output[mp.x / tw][mp.y / tw] = output[mp.x / tw][mp.y / tw].substring(1);
                    } else {
                        output[mp.x / tw][mp.y / tw] = "x" + output[mp.x / tw][mp.y / tw];
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    StringBuilder sb = new StringBuilder();
                    for (int y = 0; y < mapY; y++) {
                        for (int x = 0; x < mapX; x++) {
                            sb.append(output[x][y]);
                        }
                    }
                    System.out.println(sb.toString());
                }
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_W) {
                    output[mp.x / tw][mp.y / tw] = output[mp.x / tw][mp.y / tw].substring(0, output[mp.x / tw][mp.y / tw].length() - 1) + "w";
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    camX += 6;
                }
                if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    camY += 6;
                }
                if (e.getKeyCode() == KeyEvent.VK_X) {
                    output[mp.x / tw][mp.y / tw] = "1f";
                }
                if (e.getKeyCode() == KeyEvent.VK_2) {
                    selectedTile--;
                    if (selectedTile < 0) {
                        selectedTile = actualTiles;
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_1) {
                    selectedTile++;
                    if (selectedTile > actualTiles) {
                        selectedTile = 0;
                    }
                }
            }
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = false;
                }
            }
        });
        try {
            tile = ImageIO.read(Main.class.getResource("tiles.png"));
        } catch (IOException e) {
            System.err.println("couldn't get images");
        }
        int z = 0;
        for (int y = 0; y<8; y++) {
            for (int x = 0; x<8; x++) {
                tiles[z] = resizeImage(tile.getSubimage(x * 16, y * 16, 16, 16), tw, tw);
                z++;
            }
        }
        start();
    }

    private void start() {
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    private void stop() {
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void tick() {
        //updates 60 times a second
        mp = new Point(MouseInfo.getPointerInfo().getLocation().x - Window.frame.getLocationOnScreen().x + camX, MouseInfo.getPointerInfo().getLocation().y - Window.frame.getLocationOnScreen().y + camY - 32);
    }

    private void render() {
        //this could go like 4000 times a second but is capped at 60
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        //DRAW THINGS HERE//
        g.translate(-camX, -camY);
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0, 0, mapX, mapY);
        for (int y = 0; y < mapY; y++) {
            for (int x = 0; x < mapX; x++) {
                if (output[x][y].substring(0, 1).equals("x")) {
                    g.drawImage(flipped(tiles[Integer.parseInt(map[x][y])]), x * tw, y * tw, null);
                } else {
                    int digitAmt = 0;
                    ArrayList<Boolean> over9 = new ArrayList<>();
                    for (int z = 0; z < map[x][y].length(); z++) {
                        if (map[x][y].charAt(z) != ',') {
                            digitAmt++;
                        } else {
                            if (digitAmt == 2) {
                                over9.add(true);
                            } else {
                                over9.add(false);
                            }
                            digitAmt = 0;
                        }
                    }
                    for (int z = 0; z < 0.5f * map[x][y].length() - 0.5f; z++) {
                        if (!over9.get(z)) {
                            g.drawImage(tiles[Integer.parseInt(map[x][y].substring(2 * z, 2 * z + 1))], x * tw, y * tw, null);
                            System.out.println(Integer.parseInt(map[x][y].substring(2 * z, 2 * z + 1)));
                        } else {
                            g.drawImage(tiles[Integer.parseInt(map[x][y].substring(2 * z, 2 * z + 2))], x * tw, y * tw, null);
                        }
                    }
                    //g.drawImage(tiles[Integer.parseInt(map[x][y])], x * tw, y * tw, null);
                }
            }
        }
        g.setColor(Color.YELLOW);
        g.drawRect(9, 9, tw+1, tw+1);
        g.drawImage(tiles[selectedTile], 10, 10, null);

        g.setColor(Color.lightGray);
        g.drawRect(mp.x / tw * tw, mp.y / tw * tw, tw, tw);
        g.translate(camX, camY);
        ////////////////////
        g.dispose();
        bs.show();
    }

    public void run() {
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) /ns;
            lastTime = now;
            while(delta >= 1) {
                tick();
                render();
                frames++;
                delta--;
            }
            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                frames = 0;
            }
        }
        stop();
    }

    private BufferedImage resizeImage(final BufferedImage image, int width, int height) {
        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }

    private BufferedImage flipped(BufferedImage image) {
        AffineTransform tx = AffineTransform.getScaleInstance(-1, 1);
        tx.translate(-image.getWidth(null), 0);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
        return op.filter(image, null);
    }
}
